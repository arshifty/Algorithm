/*
#include<bits/stdc++.h>
using namespace std;


int cost[10][10],i,j,k,n,qu[10],front,rare,v,visit[10],visited[10];
int main()
{
    int m;
    //clrscr();
    cout <<"Enter no of vertices:";
    cin >> n;
    cout <<"Enter no of edges:";
    cin >> m;
    cout <<"\nEDGES \n";
    for(k=1; k<=m; k++)
    {
        cin >>i>>j;
        cost[i][j]=1;
    }
    cout <<"Enter initial vertex to traverse from:";
    cin >>v;
    cout <<"Visitied vertices:";
    cout <<v<<" ";
    visited[v]=1;
    k=1;
    while(k<n)
    {
        for(j=1; j<=n; j++)
            if(cost[v][j]!=0 && visited[j]!=1 && visit[j]!=1)
            {
                visit[j]=1;
                qu[rare++]=j;
            }
        v=qu[front++];
        cout<<v <<" ";
        k++;
        visit[v]=0;
        visited[v]=1;
    }

    return 0;
}


*/
#include<bits/stdc++.h>
using namespace std;
int arr[100],m=0;

void BFS(vector<int> G[100], int source)
{
    int i ,visited[100] = {0};
    queue<int> Q;
    Q.push(source);
    visited[source] = 1;
    printf("\n\nsource : %d" , source);
    while( !Q.empty() )
    {
        int u = Q.front();
        printf("\nqueue front : %d ", u);
        for(i=0 ; i<G[u].size() ; i++)
        {
          int  v = G[u][i];
            if(visited[v] == 0)
            {
                arr[m] = v;
                m++;
                Q.push(v);
                visited[v] = 1;
                //printf("\n visited : %d  ",v);
            }
        }

        Q.pop();
    }
}

int main()
{
    int x,y,edge,node,source,i,j;
    vector<int> G[100];
    printf("enter edge and node \n");
    scanf("%d %d",&edge,&node);

    for(i=0;i<edge;i++)
    {
        scanf("%d %d",&x,&y);
        G[x].push_back(y);
        G[y].push_back(x);

    }

    printf("enter source \n");
    scanf("%d",&source);
    BFS(G,source);
 printf("\n ");
    for(i=0;i<m;i++)
    {
        printf("%d ",arr[i]);
    }


    return 0;
}


