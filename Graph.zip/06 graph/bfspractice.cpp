#include<bits/stdc++.h>
using namespace std;
int arr[100],m=1;

void bfs(vector<int> vec[] , int source)
{
    int i, visited[100]={0};
    queue<int> q;

    q.push(source);
    visited[source]=1;

     arr[0]=source;

    while(! q.empty())
    {
        int u = q.front();
        printf("\nqueue front : %d ", u);

        for(i=0; i<vec[u].size(); i++)
        {
            int v = vec[u][i];
            if(visited[v] == 0)
            {
                arr[m]=v;
                m++;
                q.push(v);
                visited[v] = 1;
            }
        }
        q.pop();

    }





}

void display()
{
    printf("\n ");
    for(int i=0;i<m;i++)
    {
        printf("%d ",arr[i]);
    }
}

int main()
{
    vector<int> vec[100];
    int edge,node,x,y,source,i,j;
    cout<<"enter edge and node : ";
    cin>>edge>>node;
    for(i=0;i<edge;i++)
    {
        cin>>x>>y;
        vec[y].push_back(x);
        vec[x].push_back(y);
    }

    cout<<"\nenter source :";
    cin>>source;


    bfs(vec,source);

    display();

    return 0;
}
