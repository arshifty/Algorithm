#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<list>
#include<bits/stdc++.h>

using namespace std;

void addEdge(vector<int> adj[], int u,int v)
{
    adj[u].push_back(v);
    adj[v].push_back(u);

}

void DFSUtil(int u, vector<int> adj[], vector<bool> &visited)
{
    visited[u] = true;
    cout << u << " true line\n";
    for (int i=0; i<adj[u].size(); i++)
    {
         cout << u << " inside loop  \n";
        if (visited[adj[u][i]] == false)
        {
             cout << adj[u][i] << " inside recursion loop as false  \n";
            DFSUtil(adj[u][i], adj, visited);
        }
    }
}
void DFS(vector<int> adj[], int V)
{
    vector<bool> visited(V, false);
    for (int u=0; u<V; u++)
        if (visited[u] == false)
        {
            cout << visited[u] << " inside dfs method \n";
            DFSUtil(u, adj, visited);
        }
}

/*
void print(vector<int> adj[])
{
    int i;
    for(vector<int> :: iterator itr = adj.begin();  itr!=adj.end(); itr++)
    {
        cout<<*itr<<"  ";
    }

}

*/
int main()
{
    int v=10;
    vector<int> adj[v];

    addEdge(adj, 0, 1);
    addEdge(adj, 0, 4);
    addEdge(adj, 1, 2);
    addEdge(adj, 2, 3);
    addEdge(adj, 4, 5);
    addEdge(adj, 5, 3);
    addEdge(adj, 3, 6);
    addEdge(adj, 5, 7);
    addEdge(adj, 7, 8);
    addEdge(adj, 7, 9);


//    print(adj);

    DFS(adj, v);

    return 0;
}
