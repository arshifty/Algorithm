
#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<list>
#include<bits/stdc++.h>

using namespace std;

int dfsprint[100],m=0;
//int topo[100];
void addEdge(vector<int> vec[] , int u , int v)
{
    vec[u].push_back(v);
    vec[v].push_back(u);
}

void DFSUtil(int u, vector<int> vec[], vector<bool> &visited)
{
    visited[u] = true;
    dfsprint[m]=u;
    m++;
    cout<<"\n print as true  "<<u<<"\n";

    int topok=vec[u].size();
    int i=0;
    for(i=0; i<vec[u].size(); i++)
    {


         cout<<"visiting adjacent of : "<<u<<endl;

        if(visited[vec[u][i]]==false)
        {

            cout<<"\n recursion method : "<<vec[u][i]<<endl;
            DFSUtil(vec[u][i],vec,visited);
        }
        else
        {

            if(i==topok-1)
            {
  ///            topo[u+1]=u;
     ///         cout<<"topo "<<topo[u+1]<<"  u "<<u<<"\n";

            }
        }
    }

}

void DFS(vector<int> vec[],int node)
{
    vector<bool> visited(node,false);
    int u;
    for(u=0; u<node; u++)
    {
        if(visited[u]==false)
        {
            DFSUtil(u,vec,visited);
        }
    }

}

void dfsprintmethod()
{
    for(int i=0;i<m;i++)
    {
        cout<<" "<<dfsprint[i];
    }
}

int main()
{
    int node=10;
   /// cout<<"enter node number : ";
    ///cin>>node;

    vector<int> vec[node];

    addEdge(vec,0,1);
    addEdge(vec,1,2);
    addEdge(vec,2,3);
    addEdge(vec,3,6);
    addEdge(vec,3,5);
    addEdge(vec,5,4);
    addEdge(vec,5,7);
    addEdge(vec,7,8);
    addEdge(vec,7,9);

    DFS(vec,node);

    dfsprintmethod();
    return 0;
}
