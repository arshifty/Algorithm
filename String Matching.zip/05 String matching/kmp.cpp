#include<stdio.h>
#include<string.h>

int prefix[100];
void makeSuffix(char *pattern , int ln);

int main()
{
    char text[100],pattern[100];
    int i , j , position=0 , ln;

   printf("enter text :");
   gets(text);
    printf("enter pattern :");
    gets(pattern);
    ln = strlen(pattern);

    makeSuffix( pattern , ln );

      i=j=0;
      while(i<strlen(text))
      {
          if(text[i] == pattern[j])
          {

              if(j == (strlen(pattern) - 1))
              {
                  position = i - j;
                  break;
              }
              else
              {
                 i++;
                 j++;
              }
          }

          else if(j>0)
          {
              j = prefix[j-1];
          }
          else
          {
              i++;
          }

      }
          printf("\n\nPosition of Pattern in Text : %d\n",position);


    return 0;
}

void makeSuffix(char *pattern , int ln)
{

int j=1;
int i=0;

while(j<ln)
{

    if(pattern[i] == pattern[j]  )
    {
        prefix[j] = i + 1;

        i++;
        j++;

    }

    else if(i>0)
    {
        i = prefix[i-1];
    }
    else
        {
        prefix[j] = 0;
        j++;
        }


}

printf("\n\nPrefix array :  ");
    for(int k=0;k<ln;k++)
    {
        printf("%d ",prefix[k]);
    }


}










