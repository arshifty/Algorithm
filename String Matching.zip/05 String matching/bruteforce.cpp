#include<bits/stdc++.h>
using namespace std;



void search(char* txt , char* pat)
{
    int n = strlen(txt);
    int m = strlen(pat);
    int i,j;
    for(i=0;i<=n-m;i++)
    {
        bool flag = true;
        for(j=0;j<m;j++)
        {
            if(txt[i+j] != pat[j])
            {
              flag = false;
            }

        }

        if(flag == true)
            {
               cout<<"\npattern found at : "<<i;
            }
    }

}

int main()
{

    char txt[] = "AABAACAADAABAABA";
    char pat[] = "AABA";

    search(txt,pat);

    return 0;
}
