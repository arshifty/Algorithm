#include<stdio.h>
#include<string.h>

using namespace std;

int main()
{

    int sequence[100], lis[100],i,j,n;
    scanf("%d",&n);

    for(i=0;i<n;i++)
    {
        scanf("%d",&sequence[i]);
    }

    for(i=0;i<n;i++)
    {
      lis[i]=1;
    }


    for(i=0;i<n;i++)
    {

       for(j=0;j<i;j++)
       {
             if( sequence[j] < sequence[i] )
             {
                 if(lis[i] < lis[j]+1 )
                 {
                     lis[i] = lis[j] + 1;
                     printf(" \n i = %d lis : %d  , sequence : %d",i,lis[i], sequence[i]);
                 }
             }
       }


    }

    return 0;
}
