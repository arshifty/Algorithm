#include<stdio.h>
struct self
{
    int a;
    struct self *next;
};
void add(struct self a)
{
    if(a.a==0)
        return;
    printf(" %d",a.a);
    add(*a.next);
    printf(" %d",a.a);
}
int main()
{
    struct self val1,val2,val3,val4;
    val1.a=4;
    val1.next=&val2;
     val2.a=10;
     val2.next=&val3;
     val3.a=15;
     val3.next=&val4;
     val4.a=0;
     add(val1);
}
