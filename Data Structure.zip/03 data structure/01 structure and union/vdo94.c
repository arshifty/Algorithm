#include<stdio.h>
#include<string.h>

struct bucse02
    {
      char name[100];
      int sid;
       double cgpa;
    };
int main()
{
    struct bucse02 student;
    strcpy(student.name,"ashif");
    student.sid=10;
    student.cgpa=3.54;
    printf("student name =%s\n",student.name);
    printf("student ID =%d\n",student.sid);
    printf("student cgpa =%lf",student.cgpa);
return 0;
}
