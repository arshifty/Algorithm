
#include<stdio.h>
#include<string.h>


struct cse{

int roll;
char name[50];

};

void input(struct cse student[])
{
    int i;
    for( i=0;i<2;i++)
    {
        scanf("%d %s",&student[i].roll,student[i].name);
    }
}


void sort(struct cse student[])
{
    int i,j;
    for(i=0;i<2;i++)
    {
        for(j=i+1;j<2;j++)
        {

            if(strcmp(student[i].name,student[j].name) > 0)
            {

                struct cse temp;
                strcpy(temp.name,student[i].name);
                temp.roll=student[i].roll;


               strcpy( student[i].name,student[j].name);
                student[i].roll=student[j].roll;

               strcpy( student[j].name,temp.name);
               student[j].roll=temp.roll;


            }

        }
    }


}


void display(struct cse student[])
{
     int i;
     printf("\nroll\tname\n");
    for( i=0;i<2;i++)
    {
        printf("%d %s \n",student[i].roll,student[i].name);
    }
}

int main()
{
    struct cse student[100];

    input(student);
    sort(student);
    display(student);


    return 0;
}
