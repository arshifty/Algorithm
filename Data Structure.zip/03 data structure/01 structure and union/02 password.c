
#include<stdio.h>
#include<conio.h>
void pass(char pass[])
{
    char ch;
    int i=0;
    while(1)
    {
       ch=getch();
       putchar('*');
       if(ch==13)
       {
           break;
       }
       pass[i]=ch;
       i++;
    }

    pass[i]='\0';
}
int main()
{
    char password[100];
    pass(password);
    printf("\n%s",password);
}
