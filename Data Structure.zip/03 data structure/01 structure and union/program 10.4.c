#include<stdio.h>
struct marks
{
    int sub1;
    int sub2;
    int sub3;
    int total;
};
int main()
{
    int i;
    struct marks student[3]={{45,67,81,0},
                             {75,53,69,0},
                             {57,36,71,0}};

    int sub1=0;
    int sub2=0;
    int sub3=0;
     int tot=0;

for(i=0;i<=2;i++)
{
    student[i].total=student[i].sub1+student[i].sub2+student[i].sub3;

            sub1=sub1+student[i].sub1;
            sub2=sub2+student[i].sub2;
            sub3=sub3+student[i].sub3;
            tot=tot+student[i].total;


}
for(i=0;i<=2;i++)
{
    printf("student[%d] \t total :%d\n",i+1,student[i].total);
}

    printf("\nsubject \t total\n");
    printf("%s\t %d\n%s\t %d\n%s\t %d\n","subject 1",sub1,"subject 2",sub2,"subject 3",sub3);
    printf("\ngrand total=%d",tot);
}
