#include<stdio.h>
#include<string.h>
struct structure
{
    char name[100];
    int val;

};
void add(struct structure *a,struct structure *b)
{
    struct structure temp;
    strcpy(temp.name,a->name);
    temp.val=a->val;
    strcpy(a->name,b->name);
    a->val=  b->val;
    strcpy(b->name,temp.name);
    b->val= temp.val;
}
int main()
{
    struct structure val1,val2;

    printf("ENTER VALUE-1 and name:");
    scanf("%d %s",&val1.val,val1.name);
    printf("\nENTER VALUE-2 and name:");
    scanf("%d %s",&val2.val,val2.name);
    if(val2.val>val1.val)
    add(&val1,&val2);
    printf("name :%s val :%d\n",val1.name,val1.val);
    printf("name :%s val :%d\n",val2.name,val2.val);

}
