#include<stdio.h>
#include<string.h>

struct create_account
{
    char firstname[100];
    char lastname[100];
    char username[100];
    char fathername[100];
    char mothername[100];
    char nationality[100];
    char religion[100];
    char bloodgroup[100];

    char password[100];

    struct birthday
    {
        int day;
        int month;
        int year;
    }birth;

    struct SEX
    {
      int male;
      int female;
    }sex;

};
void pass(char pass[])
{
    int i=0;
    char ch;
    while(1)
    {
        ch=getch();
        if(ch==13)
            break;
        putchar('*');
        pass[i++]=ch;
    }
 pass[i]='\0';
}

int main()
{
    struct create_account user;
    char passck[100];
    char sexck[100];
printf("enter first name :");
scanf("%s",user.firstname);
printf("\nenter last name :");
scanf("%s",user.lastname);

printf("\nenter username :");
scanf("%s",user.username);
printf("\nenter fathername :");
scanf("%s",user.fathername);

printf("\nenter mothername :");
scanf("%s",user.mothername);
printf("\nenter nationality :");
scanf("%s",user.nationality);
printf("\nenter religion :");
scanf("%s",user.religion);
printf("\nenter bloodgroup :");
scanf("%s",user.bloodgroup);
printf("\nenter password :");
pass(user.password);

printf("\nrepeat password :");
pass(passck);

if(strcmp(user.password,passck) !=0)
   {
    printf("WRONG PASSWORD.....");
    return 0;
   }
printf("\nenter birthday :\n");
printf("\tday :");
scanf("%d",&user.birth.day);

printf("\tmonth :");
scanf("%d",&user.birth.month);

printf("\tyear :");
scanf("%d",&user.birth.year);
printf("SEX (for sex male press m/M ,if female press F/f) :\n");
scanf("%s",sexck);
if(strcmp(sexck,"m")==0 || strcmp(sexck,"M")==0)
{
    user.sex.male=1;
    user.sex.female=0;

}
else if(strcmp(sexck,"f")==0 || strcmp(sexck,"F")==0)
{
    user.sex.male=0;
    user.sex.female=1;

}
else
    printf("you have pressed wrong key");

printf("\n\n");
printf("FIRST NAME : %s\n",user.firstname);
printf("LAST NAME :%s\n",user.lastname);
printf("USER  NAME :%s\n",user.username);
printf("FATHER NAME :%s\n",user.fathername);
printf("MOTHER NAME :%s\n",user.mothername);
printf("NATIONALITY :%s\n",user.nationality);
printf("RELIGION :%s\n",user.religion);
printf("BLOODGROUP  :%s\n",user.bloodgroup);

printf("PASSWORD NAME :%s\n",user.password);
printf("Birthday :%d / %d / %d \n",user.birth.day,user.birth.month,user.birth.year);
if(user.sex.male==1)
   printf(" SEX : MALE");
else
    printf("SEX :FEMALE");



return 0;
}
