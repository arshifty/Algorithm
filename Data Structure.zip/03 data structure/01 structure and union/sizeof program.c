#include<stdio.h>
struct std
{
    int a;
    float b;
    char c;
    char d;
    char f;
    char g;
    char h;
    char j;
    double r;
    float p;
    int q;
};
int main()
{
    struct std as;
    printf("%d",sizeof(struct std));
}
