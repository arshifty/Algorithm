
#include<bits/stdc++.h>

using namespace std;

int main()
{
    int n,i,a,b,c,d,ans;
   while(scanf("%d",&n)!=EOF)
   {


       for(i=1;i<=n;i++)
       {
              scanf("%d %d %d",&a,&b,&c);


         ///first number

              if(b>a && b>c)
                ans=b;

                if(c>b && c>a)
                ans=c;

                if(a>b && a>c)
                ans=a;

             printf("Case %d: %d\n",i,ans);


         ///last number
/*
          if(b<a && b<c)
                ans=b;

                if(c<b && c<a)
                ans=c;

                if(a<b && a<c)
                ans=a;

             printf("Case %d: %d\n",i,ans);
*/

          ///middle number
          /*

           if(b>a && b<c || b<a && b>c)
                ans=b;

                if(c>b && c<a || c<b && c>a)
                ans=c;

                if(a>b && a<c || a<b && a>c)
                ans=a;

             printf("Case %d: %d\n",i,ans);
          */


       }


   }

 return 0;
}
