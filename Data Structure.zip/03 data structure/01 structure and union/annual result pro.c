#include<stdio.h>
#include<string.h>
struct cse
{
    char name[100];
    char subject[100];
    int number;
    int roll;
    int sum;
    };
void input( struct cse student[])
{
   int i,j,n,sum;
   //printf("\nEnter the number of student :");
   //scanf("%d",&n);
   for(i=0;i<5;i++)
   {
       printf("\nEnter student name and roll :");
       scanf("%s %d",student[i].name,&student[i].roll);
       printf("Subject Number\n");
      student[i].sum=0;
       for(j=0;j<3;j++)
         {
           scanf("%s %d",student[j].subject,&student[j].number);
           student[i].sum= student[i].sum+student[j].number;
        // printf("SUBJECT :%s \t NUMBER :%d\n",student[j].subject,student[j].number);
         }
          printf("STUDENT NAME :%s\nSTUDENT ROLL :%d\n",student[i].name,student[i].roll);
          printf("TOTAL MARKS :%d\n",student[i].sum);
           printf("\n");
        }
}

    void mark(struct cse student[])

{
    int i,j;
    for(i=0;i<4;i++)
    {
        for(j=i+1;j<5;j++)
        {
            if( student[i].sum<student[j].sum)
            {
                struct cse temp;

                strcpy(temp.name,student[i].name);
                temp.sum=student[i].sum;
                temp.roll=student[i].roll;

                strcpy(student[i].name,student[j].name);
                student[i].sum=student[j].sum;
                student[i].roll=student[j].roll;

                strcpy(student[j].name,temp.name);
                student[j].sum=temp.sum;
                student[j].roll=temp.roll;




            }

        }
    }
}
   void output(struct cse student[])
{
    int i;
    printf("The marks of the students are given below from the highest marks to lowest :\n");
    for(i=0;i<5;i++)
    {
        printf("Total marks :%d \nNAME :%s \n ROLL :%d \n", student[i].sum,student[i].name,student[i].roll);
        printf("\n");
    }
}



int main()
{
    struct cse student[100];
    printf("ANNULA EXAMINATIONS RESULTS\n");
    input(student);
    mark(student);
    output(student);

    return 0;
}
