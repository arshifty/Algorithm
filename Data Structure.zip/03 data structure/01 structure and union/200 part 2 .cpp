#include<bits/stdc++.h>
using namespace std;

int main ()
{
    char A [5000] [60], Temp[60];
    int I = 0, Len, N, J;
    int L[100] = {0};

    while (scanf("%s", Temp))
        { // input taken in Temp

        if (Temp [0] == '#') // break condition
            break;

        Len = strlen (Temp);

        for (J = 0; J < Len; J++) // Array intialized
            A [I][J] = Temp [J];



        I++;
    }

//cout<<"i=="<<I<<"\n";
    for (J = 0; J < I; J++)
        {

        for (N = 0; N < 60; N++)
            {

                if (A [J][N]  > 64 && A [J][N]  < 123)
                {
                  //  cout<<A [N] [J]<<"  "<<L [ (A [N] [J] - 65) ]<<endl;
                   //  printf("before %d\n", A [N] [J]);
                    L [ (A [J][N]  - 65) ]++;
                //  printf("after %d\n", A [N] [J]);
                }


               if (L [ ( A [J][N]  - 65) ] == 1)
               {
                    printf("%c", A [J][N] );
               }

        }
    }

    printf("\n");

    return 0;
}
