#include<stdio.h>
int main()
{
    struct student
{
    char* name;
    int age;

};
void add(struct student val)
{
   val.name="boss";
   val.age=50;
    //printf("NAME :%s \t AGE :%d\n\n",val->name,val->age);
        printf("NAME :%s \t AGE :%d\n\n",val.name,val.age);


}
struct student val,*ptr;
val.name="ashif";
val.age=32;
printf("before assign  NAME :%s \t AGE :%d\n\n",val.name,val.age);

//ptr=&val.age;
add(val);
printf("\n after NAME :%s \t AGE :%d",val.name,val.age);

}
