#include<stdio.h>

struct abc
{
    int val1;
    int val2;
    int val3;
    int total;
};
int main()
{
    struct abc student[3]={{5,1,2},{8,7,9},{7,1,6}};
    int i;
    struct abc total;
    total.total=0;
    total.val1=0;
    total.val2=0;
    total.val3=0;
    for(i=0;i<=2;i++)
    {
        student[i].total=student[i].val1+student[i].val2+student[i].val3;
        printf("student :%d\ttotal:%d\n",i+1,student[i].total);
        total.val1+= student[i].val1;
        total.val2+= student[i].val2;
        total.val3+= student[i].val3;
        total.total+=student[i].total;
    }
    printf("subject 1 :%d\n",total.val1);
        printf("subject 1 :%d\n",total.val2);
    printf("subject 1 :%d\n",total.val3);

    printf(" grand total =%d ",total.total);

}
