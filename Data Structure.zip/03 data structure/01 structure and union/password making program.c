#include<stdio.h>
#include<conio.h>
void pass(char pass[])
{
    int i=0;
    char ch;
    while(1)
    {
        ch=getch();
        if(ch==13)
           break;
        putchar('*');
        pass[i++] =ch;
    }
 pass[i]='\0';
}
int main()
{
    char password[100];
    pass(password);
 printf("\n%s",password);
}
