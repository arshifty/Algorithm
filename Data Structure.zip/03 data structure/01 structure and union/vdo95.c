#include<stdio.h>
#include<string.h>
struct bucse02
{
    char name[100];
    int sid;
    float cgpa;
};
void add(struct bucse02 student[])
{
    int i;
    for(i=0;i<3;i++)
    {
        printf("student name :%s\n",student[i].name);
        printf("student ID :%d\n",student[i].sid);
        printf("student cgpa :%f\n",student[i].cgpa);
        printf("\n");
       }
}
int main()
{
    struct bucse02 student[10];
    int i;
    for(i=0;i<3;i++)
         {
        scanf("%s %d %f",student[i].name,&student[i].sid,&student[i].cgpa);
          }
         add(student);
}
