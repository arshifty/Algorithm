#include<stdio.h>
#include<string.h>
struct cse02
{
    char name[100];
    int sid;
    float cgpa;
};

void output(struct cse02 student[])
{
    int i;
    for(i=0;i<5;i++)
    {
        printf("%.2f \n%s \n%d \n", student[i].cgpa,student[i].name,student[i].sid);
         // printf("%.2f\n", student[i].cgpa);
        printf("\n");
    }
}

void input(struct cse02 student[])
{
    int i;
    for(i=0;i<5;i++)
    {
        scanf("%s %d %f",student[i].name,&student[i].sid,&student[i].cgpa);

       // scanf("%f",&student[i].cgpa);
    }
}


void cgpasort(struct cse02 student[])
{
    int i,j;
    for(i=0;i<4;i++)
    {
        for(j=i+1;j<5;j++)
        {
            if(student[i].cgpa<student[j].cgpa)
            {
                struct cse02 temp;

                strcpy(temp.name,student[i].name);
                temp.sid=student[i].sid;
                temp.cgpa=student[i].cgpa;

                strcpy(student[i].name,student[j].name);
                student[i].sid=student[j].sid;
                student[i].cgpa=student[j].cgpa;

                strcpy(student[j].name,temp.name);
                student[j].sid=temp.sid;
                student[j].cgpa=temp.cgpa;




            }

        }
    }
}



int main()
{
    struct cse02 student[10];
    input(student);
    printf("\n\n\n");
    cgpasort(student);
    output(student);
    return 0;
}
