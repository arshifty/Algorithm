#include<bits/stdc++.h>

using namespace std;

char *index(char *s1,char *s2)
{

    int i;
    int j=0;
    int loc =0;
    for(i=0;i<strlen(s1);i++)
    {
        if(s1[i] == s2[j])
        {

            j++;
            cout<<"s2 : "<<strlen(s2)<<" j "<<j<<endl;;
            if(strlen(s2)==j)
            {
                loc=i-j+2;
            }
        }
        else
            j=0;


    }

    cout<<"location : "<<loc<<endl;


}



int main()
{

    char s1[100]={"ABCDEFGHIJ"};
    char s2[100]={"EFGH"};

    index(s1,s2);


    return 0;
}
