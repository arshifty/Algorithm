
#include<bits/stdc++.h>
using namespace std;


char *SUBSTR(char *str, int i ,int j)
{
    char a[100];
    int k, m=0;
    for(k=i-1;k<=i+j-1-1;k++)
    {
        a[m]=str[k];
        m++;
    }
    a[m]='\0';
    return a;


}

char *INSERT(char *s1,int k,char *s2)
{
    char a[100];
    strcpy(a,SUBSTR(s1,1,k-1));
    strcat(a,s2);
    int len=strlen(s1);
    strcat(a,SUBSTR(s1,k,len-k+1));
    return a;

}

int main()
{

    char s[100]={"ABCDEFGHIJKL"};
    char s1[100];
    printf("STRING :%s\n",s);
    strcpy(s1,INSERT(s,3,"XYZ"));
    printf("insert : %s",s1);


    return 0;
}
