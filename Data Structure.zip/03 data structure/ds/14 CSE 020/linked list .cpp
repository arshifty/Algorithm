#include<bits/stdc++.h>
using namespace std;
struct node
{
  int roll;
   node *next;
};
node *root=NULL;
void append(int roll)
{
	if(root==NULL)
	{
		root=new node();
		root->roll=roll;
		root->next=NULL;
	}
	else
	{
		node *current_node=root;
		while(current_node->next!=NULL)
		{
			current_node=current_node->next;
		}
		node *newnode = new node();
		newnode->roll=roll;
		newnode->next=NULL;

		current_node->next=newnode;
	}
}

void print()
{
		node *current_node=root;
		while(current_node!=NULL)
		{
			printf("%d\n",current_node->roll);
			current_node=current_node->next;
		}
}

int delete_node(int roll)
{
	node *current_node=root;
	node *previous_node=NULL;
	while(current_node->roll!=roll)
	{
		previous_node=current_node;
		current_node=current_node->next;
	}
	if(current_node==root)
	{
		node *temp=root;
		root=root->next;
		delete(temp);
	}
	else
	{
		previous_node->next=current_node->next;
		delete(current_node);
	}

}
int count()
    {
        struct node *n;
        int c=0;
        n=root;
        while(n!=NULL)
        {
        n=n->next;
        c++;
        }
        return c;
    }

int main(){
    append(1);
	append(2);
	append(6);
	print();
	cout<<count()<<endl;
	delete_node(2);
	print();
	cout<<count()<<endl;
	int i;
	while(1)
        {
        printf("\nList Operations\n");
        printf("===============\n");
        printf("1.Insert\n");
        printf("2.Print\n");
        printf("3.Count\n");
        printf("4.Delete\n");
        printf("5.Exit\n");
        printf("Enter your choice : ");
        if(scanf("%d",&i)<=0){
            printf("Enter only an Integer\n");
            exit(0);
        } else {
            switch(i)
            {
            case 1: printf("Enter the number to insert : ");
                     int num;
                     scanf("%d",&num);
                     append(num);
                     break;
            case 2:     if(root==NULL)
                    {
                    printf("List is Empty\n");
                    }
                    else
                    {
                    printf("Element(s) in the list are : ");
                    }
                    print();
                    break;
            case 3:     printf("Size of the list is %d\n",count());
                    break;
            case 4:     if(root==NULL)
                    printf("List is Empty\n");
                    else{
                    printf("Enter the number to delete : ");
                    int num;
                    scanf("%d",&num);
                    if(delete_node(num))
                        printf("%d deleted successfully\n",num);
                    else
                        printf("%d not found in the list\n",num);
                    }
                    break;
            case 5:     return 0;
            default:    printf("Invalid option\n");
            }
        }
        }
}
