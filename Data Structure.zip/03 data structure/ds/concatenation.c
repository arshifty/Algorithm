#include<stdio.h>
#include<string.h>
int main()
{
    char s1[100],s2[100];
    gets(s1);
    gets(s2);
    printf("%s\n\n",strcat(s1,s2));
    strcpy(s1,"ASHIF");
    printf("%s",strcat(strcat(s1," "),s2));

}
