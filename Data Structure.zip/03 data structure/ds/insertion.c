#include<stdio.h>
#include<string.h>
char *INSERT(char *s1,int k,char *s2);
char *SUBSTR(char *s1,int i,int j);
int main()
{
char s[80]={"ABCDEFG"};
char s1[80],s2[80],s3[80];
strcpy(s1,INSERT(s,3,"XYZ"));
printf("insert : %s",s1);

}

char *INSERT(char *s1,int k,char *s2)
{
    char a[100];
    strcpy(a,SUBSTR(s1,1,k-1));
    strcat(a,s2);
    strcat(a,SUBSTR(s1,k,strlen(s1)-k+1));
    return a;

}

char *SUBSTR(char *s1,int i,int j)
{
    int k,m=0;
    char a[100];
    for(k=i-1;k<=i+j-1-1;k++)
    {
       a[m]=s1[k];
       m++;
    }
    a[m]='\0';
    return (a);
}
