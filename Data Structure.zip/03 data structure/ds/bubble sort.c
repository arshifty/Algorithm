///bubble shot
#include<stdio.h>
int main()
{
    int DATA[100];
    int PTR,K,temp,t;
    int N;

    scanf("%d",&N);

    for(K=0;K<N;K++)
    {
        scanf("%d",&DATA[K]);
    }
     for(K=0;K<N-1;K++)
    {
            for(PTR=K;PTR<N-K;PTR++)
            {
                if(DATA[PTR]>DATA[K])
                    {
                    temp=DATA[K];
                    DATA[K]=DATA[PTR];
                    DATA[PTR]=temp;
                    }
            }

    }
    for(K=0;K<N;K++)
    {
        printf("%d ",DATA[K]);
    }
}
