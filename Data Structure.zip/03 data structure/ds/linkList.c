#include<stdio.h>

struct node
{
    int data;
    struct node *next;
};

struct node *start=NULL;
int main()
{
       char ch;
       struct node *new_node,*current;
       do
       {


       new_node=(struct node *) malloc(sizeof(struct node));
       printf("\nPlease enter the data");
       scanf("%d",&new_node->data);
       new_node->next=NULL;
       if(start==NULL)
       {
           start=new_node;
           current=new_node;
       }
       else
        {
        current->next=new_node;
        current=new_node;
        }
        printf("\nDo you want to create another node :");
        ch=getche();
       }while(ch!='n');
       printf("\nThe link list is :");

       while(start!=NULL)
       {
           printf("%d-->",start->data);
           start=start->next;
       }

       return 0;

}
