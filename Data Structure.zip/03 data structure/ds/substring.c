#include<stdio.h>
#include<string.h>
 char *SUBSTR(char*,int,int);
int main()
{
    char s[100];

    gets(s);
    printf("STRING :%s\n",s);
    printf("SUBSTRING :%s\n",SUBSTR(s,4,7));

}

char *SUBSTR(char *str,int i,int j)
{
    int k,m=0;
    char a[100];
    for(k=i-1;k<=i+j-1-1;k++)
    {
        a[m]=str[k];
        m++;
    }

    a[m]='\0';
    return (a);

}
