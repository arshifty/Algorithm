#include<stdio.h>
#include<string.h>
char *index(char *s1,char *s2)
{
    int i,loc=0,j=0;
    char a[100];
    for(i=0;i<=strlen(s1);i++)
    {

        if(s1[i]=s2[j])
        {
            loc=i+1;
            j++;
        }
       else
           j=0;
    }

        return (loc);

}
int main()
{
    char s1[80]={"ASHIFRAHMAN"};
    char s2[80]={"MAN"};
    printf(" index :%d\n",index(s1,s2));

}
