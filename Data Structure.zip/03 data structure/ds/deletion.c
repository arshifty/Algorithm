#include<stdio.h>
#include<string.h>
char *DELETE(char *s1,int k,int l);
char *SUBSTR(char *s1,int i,int j);
int main()
{
char s[80]={"ABCDEFGHIJKL"};
char s1[80],s2[80],s3[80];
printf("STRING :%s\n\n",s);
strcpy(s1,DELETE(s,2,4));
printf("\ndelete : %s",s1);

return 0;

}

char *DELETE(char *s1,int k,int l)
{
    char a[100];
    strcpy(a,SUBSTR(s1,1,k-1));
    printf("\na1: %s",a);
    strcat(a,SUBSTR(s1,k,strlen(s1)-k-l+1));

    return a;

}

char *SUBSTR(char *s1,int i,int j)
{
    int k,m=0;
    char a[100];
    for(k=i-1;k<=i+j-1-1;k++)
    {
       a[m]=s1[k];
       m++;
    }
    a[m]='\0';
    printf("\na2 : %s",a);
    return (a);
}
