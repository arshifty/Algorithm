#include<stdio.h>



struct node{
int data;
struct node *next;

};

struct node *head=NULL;

void insert(int x)
{
    struct node *new_node;
    new_node=(struct node *)malloc(sizeof(struct node  *));
    new_node->data=x;
    new_node->next=head;
    head=new_node;
}

void display()
{
     struct node *new_node;
     new_node=head;
     printf("The link list is : ");
     while(new_node!=NULL)
     {
         printf("%d-->",new_node->data);
         new_node=new_node->next;
     }
}

void delete(int n)
{
    struct node *temp1=head;
    if(n==1)
    {
        head=temp1->next;
        free(temp1);
    }
    else
    {
        int i;
        for(i=1;i<n-2;i++)
        {
            temp1=temp1->next;

        }
        struct node *temp2=temp1->next;
        temp1->next=temp2->next;
        free(temp2);
    }


}

int main()
{
    insert(17);
    insert(20);
    insert(45);
    insert(65);
    display();
int n;
printf("\nEnter a position to delete :");
scanf("%d",&n);
delete(n);
display();


     return 0;
}
