#include<bits/stdc++.h>
using namespace std;


char *SUBSTR(char *str, int i ,int j)
{
    char a[100];
    int k, m=0;
    for(k=i-1;k<=i+j-1-1;k++)
    {
        a[m]=str[k];
        m++;
    }
    a[m]='\0';
    return a;


}

int main()
{

    char s[100];
    gets(s);
    printf("STRING :%s\n",s);
    printf("SUBSTRING :%s\n",SUBSTR(s,4,7));


    return 0;
}
