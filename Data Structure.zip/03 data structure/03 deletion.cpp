#include<bits/stdc++.h>

using namespace std;


char *SUBSTR(char *s1,int i,int j)
{

    int k,m=0;
    char a[100];

    for(k=i-1;k<=i+j-1-1;k++)
    {
        a[m]=s1[k];
        m++;
    }

    a[m]='\0';
     printf("\na2 : %s\n",a);

    return a;
}

char *DELETE(char *s1,int k,int l)
{

    char a[100];
    strcpy(a,SUBSTR(s1,1,k-1));
    strcat(a,SUBSTR(s1,k, strlen(s1) - k - l + 1));

    return a;
}


int main()
{

    char s[80]={"ABCDEFGHIJKL"};
    char s1[100];
    cout<<"String : "<<s<<endl;
    strcpy(s1,DELETE(s,3,3));
    cout<<"Deletion string : "<<s1<<endl;

    return 0;
}
