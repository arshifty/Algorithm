// queue::push/pop
#include <iostream>
#include <queue>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
    queue< int > Q;
    srand(time(NULL));
    // push 5 integers
    for(int n, i=1; i<=5; i++)
    {
        n=rand();
        cout<<n<<endl;
        Q.push(n);
    }

    // pop 5 integers
    // will be popped in the same order they were pushed

    for( ; !Q.empty() ; )
    {
        cout <<"Front "<< Q.front() << "  ";
        cout << "Back "<<Q.back() << endl;
       Q.pop();
    }
    for( ; !Q.empty() ; )
    {

        Q.pop();
    }

    return 0;
}
