#include <iostream>
#include <vector>
#include <iterator>
using namespace std;

int main ()
{
vector<int> v;
for(unsigned i=0;i<10;i++)
{
    v.push_back(i*100);
    cout<<"inserting : "<<v.back()<<endl;
}
cout<<"------------------------\n\n";
while(!v.empty())
{
    cout<<"Size : "<<v.size()<<" ";
    cout<<"Last element "<<v.back()<<endl;
    v.pop_back();
}


}


/*

#include <iostream>
#include <vector>
using namespace std;

int main () {
    int n, a;
    vector< int > v;
    while(cin >> n) {
        v.resize(n);
        for(a = 0; a < n; a++) {
            cin >> v[a];
        }
        for(a = 0; a < n; a++) {
            cout << v[a] << endl;
        }
    }
    return 0;
}

*/


