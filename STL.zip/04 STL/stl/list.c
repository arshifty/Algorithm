#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>

using namespace std;

int main()
{
    list<int> lst={4,8,9,6,5};
    lst.push_back(11);
    lst.push_front(10);

    for(list<int> :: iterator ptr=lst.begin() ; ptr!=lst.end();ptr++)
    {
        cout<<*ptr<<" ";
    }
    return 0;
}
