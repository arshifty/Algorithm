#include <iostream>
#include <vector>
#include <iterator>
using namespace std;

int main ()
{
vector<int> v;
for(unsigned i=1;i<10;i++)
{
    v.push_back(i);
    cout<<v.back()<<" ";
}

v.erase(v.begin(),v.begin()+2);
cout<<"---------------\nerase the 6th element and see the range : ";
for(unsigned i=1;i<v.size();i++)
{

    cout<<v[i]<<" ";
   /// v.pop_back();

}
cout<<"\nVector size : "<<v.size();

v.clear();
cout<<"\nVector size : "<<v.size();
v.resize(10);
cout<<"\nVector size : "<<v.size();
}
