#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<list>
#include<deque>

using namespace std;

int main()
{
deque<int> dec;
dec.push_front(10);
dec.push_back(2);
dec.push_back(4);
dec.push_back(8);
dec.push_back(11);

for(deque<int> :: iterator itr=dec.begin(); itr!=dec.end();itr++)
{
    cout<<*itr<<" ";
}
cout<<"\nSize : "<<dec.size();

    deque<int> :: iterator itr=find(dec.begin(),dec.end(),10);
    dec.insert(itr,55);

cout<<endl;
sort(dec.begin(),dec.end());
for(deque<int> :: iterator itr=dec.begin(); itr!=dec.end();itr++)
{
    cout<<*itr<<" ";
}
return 0;
}
