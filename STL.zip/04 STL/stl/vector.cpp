#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<list>

using namespace std;

int main()
{
    int i;
    vector<int> vec;
    vec.push_back(444444);
    vec.push_back(1);
    vec.push_back(5);
    vec.push_back(3);
    cout<<vec[2]<<endl;
    cout<<vec.at(2);

    cout<<"\n\nVector elements :"<<endl;

    for(vector<int> :: iterator itr=vec.begin(); itr!=vec.end();itr++)
    {
         cout<<*itr<<" ";
    }
    vector<int> vec2(vec);
    cout<<"\n\nCopy Constructor Vector elements :"<<endl;

    for(vector<int> :: iterator itrConstractor=vec2.begin(); itrConstractor!=vec2.end();itrConstractor++)
    {
         cout<<*itrConstractor<<" ";
    }

    sort(vec.begin(),vec.end());
     cout<<"\n\nVector elements after sorting :"<<endl;
    for(i=0;i<vec.size();i++)
    {
        cout<<vec[i]<<" ";
    }

  if(vec.empty())
  {
      cout<<"\n\nNot possible bcz empty";
  }
  else
    cout<<"\n\nvector is not empty";

  cout<<"\n\nsize of vector : "<<vec.size();



   vec2.swap(vec);
   cout<<"\n\nVector copy constructor : "<<vec2[2];

  vec.clear();
     sort(vec.begin(),vec.end());
     cout<<"\n\nafter clear:"<<endl;
    for(i=0;i<vec.size();i++)
    {
        cout<<vec[i]<<" ";
    }
      return 0;
}
