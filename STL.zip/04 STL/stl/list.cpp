#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>

using namespace std;

int main()
{
    list<int> lst;
    lst.push_back(1);
    lst.push_back(6);
    lst.push_back(1);
    lst.push_back(6);
    lst.push_back(7);
    lst.push_back(11);
    lst.push_front(10);
    lst.push_front(100);

    cout<<"\nlist item :  ";
    for(list<int> :: iterator ptr=lst.begin() ; ptr!=lst.end();ptr++)
    {
        cout<<*ptr<<" ";
    }


    cout<<"\n\nlist item after insert and erase  :  ";
    list<int> :: iterator itr=find(lst.begin(),lst.end(),6);
    lst.insert(itr,55);

    itr++;
    lst.erase(itr);
    for(list<int> :: iterator itr=lst.begin() ; itr!=lst.end();itr++)
    {
        cout<<*itr<<" ";
    }



   return 0;
}
