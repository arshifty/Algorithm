#include <iostream>
#include <queue>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    priority_queue<int> myque;

    srand(time(null));
    cout<<"pussing some random value \n";
    for(int n,i=0;i<=6;i++)
    {
        n=rand();
        cout<<" "<<n;
        myque.push(n);

    }
    cout<<endl;

    cout<<"popping out of elements  : \n";
    while(!myque.empty())
    {
        cout<<myque.top()<<" ";
        myque.pop();
    }
    cout<<endl;
    return 0;
}
