
#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>
#include<map>

using namespace std;
int main()
{
    map<char,int> m;
    m.insert(pair<char,int> ('a',100));
    m.insert(pair<char,int> ('z',200));
    m.insert(pair<char,int> ('l',300));
    m.insert(pair<char,int> ('y',400));
   for(map<char,int> ::iterator it=m.begin();it!=m.end();it++)
   {
       cout<<(*it).first<<" "<<(*it).second<<endl;
   }

    return 0;
}
