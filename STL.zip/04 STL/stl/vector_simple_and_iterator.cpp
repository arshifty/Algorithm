#include <iostream>
#include <vector>
#include <iterator>
using namespace std;

int main ()
{
    vector< vector< int > > v2d;

    for(unsigned i=0;i<10;i++)
    {
        vector<int> temp;
        for(unsigned j=0;j<=i;j++)
        {
            temp.push_back(j);
        }
        v2d.push_back(temp);
    }


    // using iterator
    cout << "using iterator:\n";
    vector< vector< int > > :: iterator outer;
    vector< int > :: iterator inner;
      for(outer=v2d.begin();outer!=v2d.end();outer++)
    {

        for(inner=outer->begin();inner!=outer->end();inner++)
        {

            cout<<"  "<<*inner;
        }
        cout<<endl;

    }

    // using index
    cout << "\nusing indexes:\n";

       for(unsigned i=0;i<10;i++)
    {

        for(unsigned j=0;j<=i;j++)
        {

            cout<<"  "<<v2d[i][j];
        }
        cout<<endl;

    }

}
