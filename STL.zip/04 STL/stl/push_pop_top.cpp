#include <iostream>
#include <queue>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
    priority_queue<int> myque;

    // srand(time(NULL));
   cout<<"pussing some random value \n";
 ///cout<<"pussing 6  values \n";
    for(int n,i=0;i<=6;i++)
    {
   n=rand();
      /// cin>>n;
       cout<<n<<endl;
       myque.push(n);

    }
    cout<<endl;
cout<<"queue size "<<myque.size()<<endl;
    cout<<"popping out of elements  :\n";
    while(!myque.empty())
    {
        cout<<"top : "<<myque.top()<<endl;
        myque.pop();

    }
    cout<<endl;

    cout<<"\n\nqueue size  :"<<myque.size()<<endl;
    return 0;
}
