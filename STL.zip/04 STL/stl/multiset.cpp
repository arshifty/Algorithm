#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>
#include<set>

using namespace std;

int main()
{
multiset<int> ms;
ms.insert(4);
ms.insert(5);
ms.insert(9);
ms.insert(2);
ms.insert(4);
ms.insert(11);

cout<<"\nThey are always sorted and support duplicate values: "<<endl;
    for(set<int> ::iterator it=ms.begin();it!=ms.end();it++)
    {
        cout<<*it<<" ";
    }

}
