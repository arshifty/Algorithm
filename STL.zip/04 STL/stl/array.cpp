
#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>

using namespace std;

int main()
{
   char a[3]={'4','5','8'};
    cout<<a.size()<<endl;
    cout<<a.begin()<<endl;
    cout<<a.end()<<endl;

 return 0;
}
