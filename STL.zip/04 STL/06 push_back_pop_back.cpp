
#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>
#include<map>

using namespace std;
int main()
{

    vector<int> vec;
    int i;
    for(i=1;i<=10;i++)
    {
        vec.push_back(i*10);
        cout<<"inserting : "<<vec.back()<<endl;
    }

    cout<<"------------------------\n\n";
    while(!vec.empty())
    {
        cout<<"size : "<<vec.size()<<"  ";
        cout<<"Last elements : "<<vec.back()<<endl;

        vec.pop_back();
    }



return 0;
}

