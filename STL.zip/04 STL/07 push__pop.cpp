
#include <iostream>
#include <queue>
#include <ctime>
#include <cstdlib>
#include <queue>
using namespace std;
int main()
{
    queue<int> v;
    int i,n;
    for(i=0;i<10;i++)
    {
        n=rand();
        v.push(n);
        cout<<"Inserting  : "<<v.back()<<endl;
    }

    cout<<endl<<endl;
    while(!v.empty())
    {


       cout <<"Front "<< v.front() << "      ";
        cout << "Back "<<v.back() << endl;

        v.pop();
    }





return 0;
}

