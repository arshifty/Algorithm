#include<stdio.h>
#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>
#include<set>
using namespace std;
int main()
{

    set<int> myset;
    myset.insert(30);
    myset.insert(50);
    myset.insert(90);
    myset.insert(40);
    myset.insert(40);
    myset.insert(44);


    cout<<"\nThey are always sorted : "<<endl;
    for(set<int> ::iterator it=myset.begin();it!=myset.end();it++)
    {
        cout<<*it<<" ";
    }

    set<int> ::iterator it;
    it=myset.find(4);
    cout<<"\nPosition of itr :"<<*it;
    myset.insert(it,70);

    cout<<"\n\nInserted 70  : "<<endl;
    for(set<int> ::iterator it=myset.begin();it!=myset.end();it++)
    {
        cout<<*it<<" ";
    }
        myset.erase(4);
        cout<<"\n\nEreasing 9 see the list : "<<endl;
    for(set<int> ::iterator it=myset.begin();it!=myset.end();it++)
    {
        cout<<*it<<" ";
    }


    return 0;
}
