#include <iostream>
#include <queue>
#include <ctime>
#include <cstdlib>

using namespace std;

int main()
{
priority_queue<int> q;
cout<<"pussing some random value \n";
 ///cout<<"pussing 6  values \n";
    for(int n,i=0;i<=6;i++)
    {
       cin>>n;
       cout<<n<<endl;
       q.push(n);
    }

    cout<<endl;
    cout<<"queue size "<<q.size()<<endl;
    cout<<"popping out of elements  :\n";
    while(!q.empty())
    {
        cout<<"top : "<<q.top()<<endl;
        q.pop();

    }
    cout<<endl;
    cout<<"\n\nqueue size  :"<<q.size()<<endl;


 return 0;
}

