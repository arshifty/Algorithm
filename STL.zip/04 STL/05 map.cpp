
#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<numeric>
#include<list>
#include<deque>
#include<map>

using namespace std;
int main()
{

map<char,int> mp;

mp.insert(pair<char,int> ('A',100));
mp.insert(pair<char,int> ('B',50));
mp.insert(pair<char,int> ('l',300));
mp.insert(pair<char,int> ('y',400));


for(map<char,int> :: iterator itr=mp.begin(); itr!=mp.end(); itr++)
{
    cout<<(*itr).first<<"   " <<(*itr).second<<endl;
}

map<int,int> mp1;

mp1.insert(pair<int,int> (1,100));
mp1.insert(pair<int,int> (2,50));
mp1.insert(pair<int,int> (3,300));
mp1.insert(pair<int,int> (4,400));


for(map<int,int> :: iterator itr=mp1.begin(); itr!=mp1.end(); itr++)
{
    cout<<(*itr).first<<"   " <<(*itr).second<<endl;
}



return 0;
}
