#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<list>
#include<bits/stdc++.h>

using namespace std;

int main()
{
list<int> lst;

 int n,i,val,m;

    cout<<"how : ";
    cin>>n;
    cout<<"Enter elements : \n";
    for(i=0;i<n;i++)
    {
        cin>>m;
        lst.push_back(m);
    }

    cout<<"List's Elements : \n";

    list<int> :: iterator itr;
    for(itr=lst.begin() ; itr!=lst.end();itr++)
    {
        cout<<*itr<<" ";
    }

    cout<<"\n\ninsert and erase  : \n\n";
     itr=find(lst.begin(),lst.end(),3);
    lst.insert(itr,100);

    itr++;
   // lst.erase(itr);
    for(list<int> :: iterator itr=lst.begin() ; itr!=lst.end();itr++)
    {
        cout<<*itr<<" ";
    }



 return 0;
}
