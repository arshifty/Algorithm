#include<iostream>
#include<cstdio>
#include<vector>
#include<iterator>
#include<algorithm>
#include<functional>
#include<list>
#include<bits/stdc++.h>

using namespace std;

int main()
{
    vector<int> vec;
    int n,i,val,m;
    cout<<"how : ";
    cin>>n;
    cout<<"Enter elements : \n";
    for(i=0;i<n;i++)
    {
        cin>>m;
        vec.push_back(m);
    }

    cout<<"Vector's Elements : \n";
    for(i=0;i<vec.size();i++)
    {
      cout<<vec[i]<<"   ";
    }

    sort(vec.begin(),vec.end());
    cout<<"\n\nVector elements after sorting :"<<endl;
    for(i=0;i<vec.size();i++)
    {
        cout<<vec[i]<<" ";
    }

    cout<<"\nIterator system \n";
    for(vector<int> :: iterator itr = vec.begin();  itr!=vec.end(); itr++)
    {
        cout<<*itr<<"  ";
    }

int j;
for(i=0;i<vec.size();i++)
{
    for(j=i;j<vec.size();j++)
    {
        if(vec[i] < vec[j])
        {
            int temp = vec[i];
            vec[i] = vec[j];
            vec[j] = temp;
        }
    }
}

    cout<<"\n\nBubble sort :"<<endl;
    for(i=0;i<vec.size();i++)
    {
        cout<<vec[i]<<" ";
    }


 return 0;
}
